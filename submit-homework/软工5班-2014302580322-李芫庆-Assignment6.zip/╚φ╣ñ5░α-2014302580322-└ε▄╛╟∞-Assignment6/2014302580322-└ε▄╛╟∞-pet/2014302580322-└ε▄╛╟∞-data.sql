/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('1','dog','bone','water','ground','play','30','3','10','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('2','cat','fish','milk','roof','hug','15','6','48','good;');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('3','turtle','fish,shrimp','sea water','sea water','bask','40','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('4','parrot','nuts,seeds','water','tree','fly','10','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('5','hamster','Sunflower seed','water','corner','eat','50','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('6','squirrel','pine cone','water','tree hole,underground','play','40','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('7','rabbit','carrot','water','grassland,underground','eat','30','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('8','snake','mouse','water','hole','bask','44','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('9','lizard','bug','water','tree','bask','59','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('10','fish','aquatic plant','water','water','swim','44','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('11','myna','earthworm','water','tree','fly','29','0','50','暂无评价');
insert into `2014302580322_pet` (`id`, `name`, `eat`, `drink`, `live`, `hobby`, `price`, `sellnumbers`, `leftnumbers`, `comment`) values('12','canary','millet','water','tree','sing','69','0','50','暂无评价');
