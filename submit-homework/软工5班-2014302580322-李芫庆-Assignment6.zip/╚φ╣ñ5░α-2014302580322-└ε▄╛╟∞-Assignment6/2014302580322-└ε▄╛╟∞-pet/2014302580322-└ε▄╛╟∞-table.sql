/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580322_pet` (
	`id` int (11),
	`name` varchar (765),
	`eat` varchar (765),
	`drink` varchar (765),
	`live` varchar (765),
	`hobby` varchar (765),
	`price` int (100),
	`sellnumbers` int (100),
	`leftnumbers` int (100),
	`comment` varchar (765)
); 
