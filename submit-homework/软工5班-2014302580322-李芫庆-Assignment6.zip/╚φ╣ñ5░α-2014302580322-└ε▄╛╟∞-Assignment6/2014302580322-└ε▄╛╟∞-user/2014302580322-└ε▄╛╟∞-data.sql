/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

insert into `2014302580322_user` (`name`, `balance`) values('','');
insert into `2014302580322_user` (`name`, `balance`) values('2753079667@qq.com','94.0');
