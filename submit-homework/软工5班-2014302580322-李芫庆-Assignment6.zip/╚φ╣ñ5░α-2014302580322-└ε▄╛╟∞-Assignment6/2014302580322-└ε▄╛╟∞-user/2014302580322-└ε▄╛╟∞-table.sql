/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.21 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `2014302580322_user` (
	`name` varchar (765),
	`balance` varchar (765)
); 
