package tianMao;

import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/*
 * ��¼����
 */
public class Login extends JPanel{
	private JButton login=new JButton("��¼");
	//�����������
	private JTextField email=new JTextField();
	//���������֤��
	private JTextField password=new JTextField();
	private JLabel emaiLabel=new JLabel("���������˺�");
	private JButton recive=new JButton("������֤��");
	private JLabel passwordLabel=new JLabel("�����ܵ�����֤��");
	private String yanzhengma="��";
	public static boolean isLogin=false;
	private int count=0;
	protected static User user;
	public Login()
	{
		setLayout(new GridLayout(3,2,20,20));
		//����������֤��
		recive.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
					String em="\\w+(\\.\\w+)*@\\w+(\\.\\w+)+";
					count=0;
					if(!email.getText().matches(em))
					{
						email.setText("�����ʽ����ȷ");
						return;
					}
					Properties properties=new Properties();
					properties.setProperty("mail.smtp.auth", "true");
					properties.setProperty("mail.smtp.host","smtp.sina.com");
					Session session=Session.getInstance(properties,new Authenticator() {
						protected PasswordAuthentication getPasswordAuthentication()
						{
							return new PasswordAuthentication("skyfirst11@sina.com", "lllllll1");
						}
					});
					MimeMessage message=new MimeMessage(session);
					try {
						message.setFrom(new InternetAddress("skyfirst11@sina.com"));
						message.setRecipient(RecipientType.TO, new InternetAddress(email.getText()));
						message.setSubject("��֤��");
						Random random=new Random();
						yanzhengma="";
						for(int i=0;i<6;i++)
						{
							yanzhengma=yanzhengma+String.valueOf(random.nextInt(10));
						}
						message.setText("������֤����"+yanzhengma+"���Ʊ��ܣ���Ҫ���׸�֪����");
						message.saveChanges();
						Transport.send(message);
					} catch (Exception e1) {
				
					}

			}
		});
		//��¼
		login.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(password.getText().equals(yanzhengma)&&count==0)
				{
					user=new User(email.getText());
					user.setBalance(Float.parseFloat(ConnectMysql.getBalance(user.getName())));
					isLogin=true;
					PetSimpleInfo.app.setSize(Toolkit.getDefaultToolkit().getScreenSize().width,Toolkit.getDefaultToolkit().getScreenSize().height);
					PetSimpleInfo.app.setLocation(0,0);
					App.cardLayout.next(App.container);
					PetSimpleInfo.app.setTitle("��è�̳ǻ�ӭ"+user.getName()+"�û�");
					count=1;
				}
				else {
					password.setText("��֤������");
				}
			}
		});
		add(emaiLabel);
		add(email);
		add(passwordLabel);
		add(password);
		add(recive);
		add(login);
		
	}
}
