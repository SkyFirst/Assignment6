package tianMao;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.lang.model.type.PrimitiveType;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
/*
 * ����չʾ���������Ϣ
 */
public class PetSimpleInfo extends JPanel{
	protected static App app;
	private JButton dogButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel 	dogLabel=new JLabel();
	private JButton catButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel catLabel=new JLabel();
	private JButton turtleButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel turtleLabel=new JLabel();
	private JButton parrotButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel parrotLabel=new JLabel();
	private JButton hamsterButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel hamsterLabel=new JLabel();
	private JButton squirreButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel squirreLabel=new JLabel();
	private JButton rabbitButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel rabbitLabel=new JLabel();
	private JButton snakeButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel snakeLabel=new JLabel();
	private JButton lizardButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel lizardLabel=new JLabel();
	private JButton fishButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel fishLabel=new JLabel();
	private JButton mynaButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel mynaLabel=new JLabel();
	private JButton canaryButton=new JButton("����鿴��ϸ��Ϣ");
	private JLabel canaryLabel=new JLabel();
	public PetSimpleInfo()
	{
		PetFactory petFactory=new PetFactory();
		final Dog1 dog=petFactory.getDog1();
		dogLabel.setIcon(new ImageIcon(("image\\dog.jpg")));
		dogLabel.setText("<html>"+dog.getName()+"<br>"+dog.price()+"</html>");
		dogLabel.setHorizontalTextPosition(JLabel.CENTER);
		dogLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Cat2 cat=petFactory.getCat2();
		catLabel.setIcon(new ImageIcon(("image\\cat.jpg")));
		catLabel.setText("<html>"+cat.getName()+"<br>"+cat.price()+"</html>");
		catLabel.setHorizontalTextPosition(JLabel.CENTER);
		catLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Turtle3 turtle=petFactory.getTurtle3();
		turtleLabel.setIcon(new ImageIcon(("image\\turtle.jpg")));
		turtleLabel.setText("<html>"+turtle.getName()+"<br>"+turtle.price()+"</html>");
		turtleLabel.setHorizontalTextPosition(JLabel.CENTER);
		turtleLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Parrot4 parrot=petFactory.getParrot4();
		parrotLabel.setIcon(new ImageIcon(("image\\parrot.jpg")));
		parrotLabel.setText("<html>"+parrot.getName()+"<br>"+parrot.price()+"</html>");
		parrotLabel.setHorizontalTextPosition(JLabel.CENTER);
		parrotLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Hamster5 hamster=petFactory.getHamster5();
		hamsterLabel.setIcon(new ImageIcon(("image\\hamster.jpg")));
		hamsterLabel.setText("<html>"+hamster.getName()+"<br>"+hamster.price()+"</html>");
		hamsterLabel.setHorizontalTextPosition(JLabel.CENTER);
		hamsterLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Squirrel6 squirrel=petFactory.getSquirrel6();
		squirreLabel.setIcon(new ImageIcon(("image\\squirrel.jpg")));
		squirreLabel.setText("<html>"+squirrel.getName()+"<br>"+squirrel.price()+"</html>");
		squirreLabel.setHorizontalTextPosition(JLabel.CENTER);
		squirreLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Rabbit7 rabbit=petFactory.getRabbit7();
		rabbitLabel.setIcon(new ImageIcon(("image\\rabbit.jpg")));
		rabbitLabel.setText("<html>"+rabbit.getName()+"<br>"+rabbit.price()+"</html>");
		rabbitLabel.setHorizontalTextPosition(JLabel.CENTER);
		rabbitLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Snake8 snake=petFactory.getSnake8();
		snakeLabel.setIcon(new ImageIcon(("image\\snake.jpg")));
		snakeLabel.setText("<html>"+snake.getName()+"<br>"+snake.price()+"</html>");
		snakeLabel.setHorizontalTextPosition(JLabel.CENTER);
		snakeLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Lizard9 lizard=petFactory.getLizard9();
		lizardLabel.setIcon(new ImageIcon(("image\\lizard.jpg")));
		lizardLabel.setText("<html>"+lizard.getName()+"<br>"+lizard.price()+"</html>");
		lizardLabel.setHorizontalTextPosition(JLabel.CENTER);
		lizardLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Fish10 fish=petFactory.getFish10();
		fishLabel.setIcon(new ImageIcon(("image\\fish.jpg")));
		fishLabel.setText("<html>"+fish.getName()+"<br>"+fish.price()+"</html>");
		fishLabel.setHorizontalTextPosition(JLabel.CENTER);
		fishLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Myna11 myna=petFactory.getMyna11();
		mynaLabel.setIcon(new ImageIcon(("image\\myna.jpg")));
		mynaLabel.setText("<html>"+myna.getName()+"<br>"+myna.price()+"</html>");
		mynaLabel.setHorizontalTextPosition(JLabel.CENTER);
		mynaLabel.setVerticalTextPosition(JLabel.BOTTOM);
		final Canary12 canary=petFactory.getCanary12();
		canaryLabel.setIcon(new ImageIcon(("image\\canary.jpg")));
		canaryLabel.setText("<html>"+canary.getName()+"<br>"+canary.price()+"</html>");
		canaryLabel.setHorizontalTextPosition(JLabel.CENTER);
		canaryLabel.setVerticalTextPosition(JLabel.BOTTOM);
		GridBagLayout g=new GridBagLayout();
		GridBagConstraints gridBagConstraints=new GridBagConstraints();
		setLayout(g);
		gridBagConstraints.fill=GridBagConstraints.BOTH;
		gridBagConstraints.gridheight=3;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(dogLabel, gridBagConstraints);
		g.setConstraints(catLabel,gridBagConstraints);
		g.setConstraints(turtleLabel,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(parrotLabel,gridBagConstraints);
		gridBagConstraints.gridheight=1;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(dogButton,gridBagConstraints);
		g.setConstraints(catButton,gridBagConstraints);
		g.setConstraints(turtleButton,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(parrotButton,gridBagConstraints);
		gridBagConstraints.gridheight=3;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(hamsterLabel,gridBagConstraints);
		g.setConstraints(squirreLabel,gridBagConstraints);
		g.setConstraints(rabbitLabel,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(snakeLabel, gridBagConstraints);
		gridBagConstraints.gridheight=1;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(hamsterButton,gridBagConstraints);
		g.setConstraints(squirreButton,gridBagConstraints);
		g.setConstraints(rabbitButton,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(snakeButton,gridBagConstraints);
		gridBagConstraints.gridheight=3;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(lizardLabel,gridBagConstraints);
		g.setConstraints(fishLabel,gridBagConstraints);
		g.setConstraints(mynaLabel,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(canaryLabel,gridBagConstraints);
		gridBagConstraints.gridheight=1;
		gridBagConstraints.gridwidth=4;
		g.setConstraints(lizardButton,gridBagConstraints);g.setConstraints(fishButton,gridBagConstraints);
		g.setConstraints(mynaButton,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		g.setConstraints(canaryButton,gridBagConstraints);
		add(dogLabel);
		add(catLabel);
		add(turtleLabel);
		add(parrotLabel);
		add(dogButton);
		add(catButton);
		add(turtleButton);
		add(parrotButton);
		add(hamsterLabel);
		add(squirreLabel);
		add(rabbitLabel);
		add(snakeLabel);
		add(hamsterButton);
		add(squirreButton);
		add(rabbitButton);
		add(snakeButton);
		add(lizardLabel);
		add(fishLabel);
		add(mynaLabel);
		add(canaryLabel);
		add(lizardButton);
		add(fishButton);
		add(mynaButton);
		add(canaryButton);
		dogButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "1");
				
			}
		});
		catButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "2");// TODO Auto-generated method stub
				
			}
		});
		turtleButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				App.cardLayout.show(App.container, "3");
			}
		});
		parrotButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "4");
				
			}
		});
		hamsterButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "5");
			}
		});
		squirreButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "6");
			}
		});
		rabbitButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "7");
			}
		});
		snakeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "8");
			}
		});
		lizardButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "9");
			}
		});
		fishButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "10");
			}
		});
		mynaButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "11");
			}
		});
		canaryButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				App.cardLayout.show(App.container, "12");	
			}
		});
		
	}
}
