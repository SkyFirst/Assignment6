package tianMao;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
/*
 * �����������ݿ�
 */
public class ConnectMysql {
	private  static Connection connection=null;
	private  static PreparedStatement statement;
	private static PreparedStatement statement2;
	//��������
	public static ResultSet connect()
	{
		try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=(Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?useUnicode=true&characterEncoding=gb2312","root","123456");
				statement=(PreparedStatement) connection.prepareStatement("select * from 2014302580322_pet ");
				statement2=(PreparedStatement) connection.prepareStatement("select * from 2014302580322_user ");
				return statement.executeQuery();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	//��ȡ������Ϣ
	public static String getInfo(int id)
	{
		ResultSet set=connect();
		int ID=1;
		try {
			while(set.next())
			{	
				if(id==ID)
				{
					return set.getString(2)+"+eat: "+set.getString(3)+"+drink: "+set.getString(4)+"+live: "+set.getString(5)+"+hobby: "+set.getString(6)+"+price: "+set.getString(7)+"+"+set.getString(8)+"+"+set.getString(9)+"+comment: "+set.getString(10);
				}
				ID++;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	//��ȡ�û����
	public static String getBalance(String name)
	{
		connect();
		try {
			ResultSet resultSet=statement2.executeQuery();
			while(resultSet.next())
			{
				if(resultSet.getString(1).equals(name))
				{
					return resultSet.getString(2);
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new String("0");
	}
	//�ر�����
	public static void close()
	{
		try {
			statement.close();
			statement2.close();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//�����ݿ������߸�������
	public static void insertOrUpdate(String na,String bala)
	{
		boolean b=false;
		ResultSet set;
		try {
			set = statement2.executeQuery();
			while(set.next())
			{
				if(set.getString(1).equals(na))
				{
					b=true;
					break;
				}
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if(b==false)
		{
			try {
				statement2=(PreparedStatement) connection.prepareStatement("insert into 2014302580322_user(name,balance)values('"+na+"','"+bala+"')");
				statement2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return;
		}
		try {
			statement2=(PreparedStatement) connection.prepareStatement("update 2014302580322_user set balance='"+bala+"' where name ='"+na+"'");
			statement2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//�����ݿ��м����û�����
	public static void setComment(String comm)
	{
		try {
			ResultSet set=statement.executeQuery();
			while(set.next())
			{
				for(String item :comm.split("\n"))
				{
					if(set.getString(2).equals(item.split(";")[0]))
					{    String commen=item.split(";")[1];
						if(!set.getString(10).equals("��������"))
						{
							commen=set.getString(10)+commen+";";
						}else {
							commen=commen+";";
						}
						
						PreparedStatement sta=(PreparedStatement)connection.prepareStatement("update 2014302580322_pet set comment='"+commen+"' where name ='"+set.getString(2)+"'");
								sta.executeUpdate();
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	//�ı����ݿ��е��������һ��
	public static void setSellNumber(String s)
	{
		try {
			ResultSet set=statement.executeQuery();
			while(set.next())
			{
				for(String item:s.split("\n"))
				{
					if(item.split(" ")[0].equals(set.getString(2)))
					{
						int num1=Integer.parseInt(set.getString(8));
						int num2=Integer.parseInt(set.getString(9));
						num1=num1+Integer.parseInt(item.split("\\*")[1]);
						num2=num2-Integer.parseInt(item.split("\\*")[1]);
						PreparedStatement sta=(PreparedStatement)connection.prepareStatement("update 2014302580322_pet set sellnumbers='"+String.valueOf(num1)+"' where name ='"+set.getString(2)+"'");
						sta.executeUpdate();
						sta=(PreparedStatement)connection.prepareStatement("update 2014302580322_pet set leftnumbers='"+String.valueOf(num2)+"' where name ='"+set.getString(2)+"'");
						sta.executeUpdate();
						
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	//�����жϿ�������Ƿ���
	public static boolean canBuy(String s)
	{
		try {
			ResultSet set=statement.executeQuery();
			while(set.next())
			{
				for(String item:s.split("\n"))
				{
					if(item.split(" ")[0].equals(set.getString(2)))
					{
						int num2=Integer.parseInt(set.getString(9));
						if((num2-Integer.parseInt(item.split("\\*")[1])<0))
						{
							return false;
						}
						
					}
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return true;
	}
	
	
}
