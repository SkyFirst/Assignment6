package tianMao;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
/*
 * ������ϸ��Ϣչʾ����
 * 
 */
public class PetComplexInfo extends JPanel{
	private  JLabel info=null;
	private  JButton buyButton=null;
	private  JButton shopCar=null;
	private  JButton back=null;
	private  JButton outB=null;
	private JButton jiangou=null;
	private JButton look=null;
	private JButton chongz=null;
	private JButton balace=null;
	private Dog1 dog;
	private Cat2 cat;
	private Turtle3 turtle;
	private Parrot4 parrot;
	private Hamster5 hamster;
	private Squirrel6 squirrel;
	private Rabbit7 rabbit;
	private Snake8 snake;
	private Lizard9 lizard;
	private Fish10 fish;
	private Myna11 myna;
	private Canary12 canary;
	private  static String buy="";
	//�������û�չʾ���ﳵ��Ϣ�䱳����shopInfo֧��
	protected static String carShopShowMessage="";
	public  PetComplexInfo(final int id)
	{
		PetFactory petFactory=new PetFactory();
		buyButton=new JButton("����");
		shopCar=new JButton("���ﳵ");
		 back=new JButton("����");
		 outB=new JButton("�˳���¼");
		 info=new JLabel();
		 look=new JButton("�鿴���ﳵ");
		 jiangou=new JButton("����");
		 balace=new JButton("�鿴���");
		 chongz=new JButton("��ֵ");
		switch(id)
		{
		case 1:
				dog=petFactory.getDog1();
				info.setIcon(new ImageIcon(("image\\dog.jpg")));
				info.setText("<html>"+dog.getName()+"<br>"+dog.eat()+" "+dog.drink()+" "+dog.live()+"<br>"+dog.hobby()+" ����:"+dog.sellNumbers()+"  ��� :"+dog.leftNumbers()+"<br>"+dog.comment()+" "+dog.price()+"</html>");
				break;
		case 2:
			cat=petFactory.getCat2();
			info.setIcon(new ImageIcon(("image\\cat.jpg")));
			info.setText("<html>"+cat.getName()+"<br>"+cat.eat()+" "+cat.drink()+" "+cat.live()+"<br>"+cat.hobby()+" ����: "+cat.sellNumbers()+"  ���: "+cat.leftNumbers()+"<br>"+cat.comment()+" "+cat.price()+"</html>");
			break;
		case 3:
			turtle=petFactory.getTurtle3();
			info.setIcon(new ImageIcon(("image\\turtle.jpg")));
			info.setText("<html>"+turtle.getName()+"<br>"+turtle.eat()+" "+turtle.drink()+" "+turtle.live()+"<br>"+turtle.hobby()+" ����:"+turtle.sellNumbers()+"  ���: "+turtle.leftNumbers()+"<br>"+turtle.comment()+" "+turtle.price()+"</html>");
			break;
		case 4:
			parrot=petFactory.getParrot4();
			info.setIcon(new ImageIcon(("image\\parrot.jpg")));
			info.setText("<html>"+parrot.getName()+"<br>"+parrot.eat()+" "+parrot.drink()+" "+parrot.live()+"<br>"+parrot.hobby()+" ���� :"+parrot.sellNumbers()+"  ��� :"+parrot.leftNumbers()+"<br>"+parrot.comment()+" "+parrot.price()+"</html>");
			break;
		case 5:
			hamster=petFactory.getHamster5();
			info.setIcon(new ImageIcon(("image\\hamster.jpg")));
			info.setText("<html>"+hamster.getName()+"<br>"+hamster.eat()+" "+hamster.drink()+" "+hamster.live()+"<br>"+hamster.hobby()+" ���� :"+hamster.sellNumbers()+"  ���: "+hamster.leftNumbers()+"<br>"+hamster.comment()+" "+hamster.price()+"</html>");
			break;
		case 6:
			squirrel=petFactory.getSquirrel6();
			info.setIcon(new ImageIcon(("image\\squirrel.jpg")));
			info.setText("<html>"+squirrel.getName()+"<br>"+squirrel.eat()+" "+squirrel.drink()+" "+squirrel.live()+"<br>"+squirrel.hobby()+" ���� :"+squirrel.sellNumbers()+"  ��� :"+squirrel.leftNumbers()+"<br>"+squirrel.comment()+" "+squirrel.price()+"</html>");
			break;
		case 7:
			rabbit=petFactory.getRabbit7();
			info.setIcon(new ImageIcon(("image\\rabbit.jpg")));
			info.setText("<html>"+rabbit.getName()+"<br>"+rabbit.eat()+" "+rabbit.drink()+" "+rabbit.live()+"<br>"+rabbit.hobby()+" ����: "+rabbit.sellNumbers()+"  ��� :"+rabbit.leftNumbers()+"<br>"+rabbit.comment()+" "+rabbit.price()+"</html>");
			break;	
		case 8:
			snake=petFactory.getSnake8();
			info.setIcon(new ImageIcon(("image\\snake.jpg")));
			info.setText("<html>"+snake.getName()+"<br>"+snake.eat()+" "+snake.drink()+" "+snake.live()+"<br>"+snake.hobby()+" ����: "+snake.sellNumbers()+"  ��� :"+snake.leftNumbers()+"<br>"+snake.comment()+" "+snake.price()+"</html>");
			break;	
		case 9:
			lizard=petFactory.getLizard9();
			info.setIcon(new ImageIcon(("image\\lizard.jpg")));
			info.setText("<html>"+lizard.getName()+"<br>"+lizard.eat()+" "+lizard.drink()+" "+lizard.live()+"<br>"+lizard.hobby()+" ���� :"+lizard.sellNumbers()+"  ���: "+lizard.leftNumbers()+"<br>"+lizard.comment()+" "+lizard.price()+"</html>");
			break;
		case 10:
			fish=petFactory.getFish10();
			info.setIcon(new ImageIcon(("image\\fish.jpg")));
			info.setText("<html>"+fish.getName()+"<br>"+fish.eat()+" "+fish.drink()+" "+fish.live()+"<br>"+fish.hobby()+" ���� :"+fish.sellNumbers()+"  ��� :"+fish.leftNumbers()+"<br>"+fish.comment()+" "+fish.price()+"</html>");
			break;
		case 11:
			myna=petFactory.getMyna11();
			info.setIcon(new ImageIcon(("image\\myna.jpg")));
			info.setText("<html>"+myna.getName()+"<br>"+myna.eat()+" "+myna.drink()+" "+myna.live()+"<br>"+myna.hobby()+" ���� :"+myna.sellNumbers()+"  ��� :"+myna.leftNumbers()+"<br>"+myna.comment()+" "+myna.price()+"</html>");
			break;
		case 12:
			canary=petFactory.getCanary12();
			info.setIcon(new ImageIcon(("image\\canary.jpg")));
			info.setText("<html>"+canary.getName()+"<br>"+canary.eat()+" "+canary.drink()+" "+canary.live()+"<br>"+canary.hobby()+" ���� :"+canary.sellNumbers()+"  ���: "+canary.leftNumbers()+"<br>"+canary.comment()+" "+canary.price()+"</html>");
			break;
		default:
			
		}
		info.setHorizontalTextPosition(JLabel.CENTER);
		info.setVerticalTextPosition(JLabel.BOTTOM);
		GridBagLayout grid=new GridBagLayout();
		setLayout(grid);
		GridBagConstraints gridBagConstraints=new GridBagConstraints();
		gridBagConstraints.fill=GridBagConstraints.BOTH;
		gridBagConstraints.gridwidth=3;
		gridBagConstraints.gridheight=2;
		grid.setConstraints(back,gridBagConstraints );
		grid.setConstraints(chongz,gridBagConstraints );
		grid.setConstraints(balace,gridBagConstraints );
		gridBagConstraints.gridwidth=0;
		grid.setConstraints(outB, gridBagConstraints);
		gridBagConstraints.gridwidth=25;
		gridBagConstraints.gridheight=7;
		gridBagConstraints.gridwidth=0;
		grid.setConstraints(info, gridBagConstraints);
		gridBagConstraints.gridwidth=3;
		gridBagConstraints.gridheight=2;
		grid.setConstraints(shopCar,gridBagConstraints);
		grid.setConstraints(jiangou,gridBagConstraints);
		grid.setConstraints(look,gridBagConstraints);
		gridBagConstraints.gridwidth=0;
		grid.setConstraints(buyButton, gridBagConstraints);
		add(back);
		add(chongz);
		add(balace);
		add(outB);
		add(info);
		add(shopCar);
		add(jiangou);
		add(look);
		add(buyButton);
		//���ذ�ť
		back.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				App.cardLayout.show(App.container,"0");
			}
		});
		//�˳���¼��ť
		outB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				 ConnectMysql.insertOrUpdate(Login.user.getName(), String.valueOf(Login.user.getBalance()));
				 Login.user.clear();
				PetSimpleInfo.app.setSize(400,200);
				App.cardLayout.first(App.container);
				PetSimpleInfo.app.setTitle("��è�̳�");
				PetSimpleInfo.app.setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2-200,Toolkit.getDefaultToolkit().getScreenSize().height/2-100);
			}
		});
		//���ﳵ��ť
		shopCar.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Login.user.shopNumber++;		
				shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
				switch(id)
				{
					case 1:
						Login.user.shopCar(dog.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(dog.price().split(" ")[1]));
						break;
					case 2:
						Login.user.shopCar(cat.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(cat.price().split(" ")[1]));
						break;
					case 3:
						Login.user.shopCar(turtle.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(turtle.price().split(" ")[1]));
						break;
					case 4:
						Login.user.shopCar(parrot.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(parrot.price().split(" ")[1]));
						break;
					case 5:
						Login.user.shopCar(hamster.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(hamster.price().split(" ")[1]));
						break;
					case 6:
						Login.user.shopCar(squirrel.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(squirrel.price().split(" ")[1]));
						break;
					case 7:
						Login.user.shopCar(rabbit.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(rabbit.price().split(" ")[1]));
						break;
					case 8:
						Login.user.shopCar(snake.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(snake.price().split(" ")[1]));
						break;
					case 9:
						Login.user.shopCar(lizard.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(lizard.price().split(" ")[1]));
						break;
					case 10:
						Login.user.shopCar(fish.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(fish.price().split(" ")[1]));
						break;
					case 11:
						Login.user.shopCar(myna.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(myna.price().split(" ")[1]));
						break;
					case 12:
						Login.user.shopCar(canary.getName());
						Login.user.calPrice(Login.user.shopPrice,Float.parseFloat(canary.price().split(" ")[1]));
						break;
				}
			}// TODO Auto-generated method stub
			
		});
		//�鿴���ﳵ��ť
		look.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
					int count=0;
					switch (id) {
					case 1:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,dog.getName());
						if(Login.user.shopInfo.indexOf(dog.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(dog.getName())-Login.user.shopInfo.indexOf(dog.getName());
							count=count/dog.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, dog.getName(),dog.getName()+"  *"+count+"\n");
						}
						break;
					case 2:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,cat.getName());
						if(Login.user.shopInfo.indexOf(cat.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(cat.getName())-Login.user.shopInfo.indexOf(cat.getName());
							count=count/cat.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, cat.getName(),cat.getName()+"  *"+count+"\n");
						}
						break;
					case 3:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,turtle.getName());
						if(Login.user.shopInfo.indexOf(turtle.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(turtle.getName())-Login.user.shopInfo.indexOf(turtle.getName());
							count=count/turtle.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, turtle.getName(),turtle.getName()+"  *"+count+"\n");
						}
						break;
					case 4:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,parrot.getName());
						if(Login.user.shopInfo.indexOf(parrot.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(parrot.getName())-Login.user.shopInfo.indexOf(parrot.getName());
							count=count/parrot.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, parrot.getName(),parrot.getName()+"  *"+count+"\n");
						}
						break;
					case 5:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,hamster.getName());
						if(Login.user.shopInfo.indexOf(hamster.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(hamster.getName())-Login.user.shopInfo.indexOf(hamster.getName());
							count=count/hamster.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, hamster.getName(),hamster.getName()+"  *"+count+"\n");
						}
						break;
					case 6:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,squirrel.getName());
						if(Login.user.shopInfo.indexOf(squirrel.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(squirrel.getName())-Login.user.shopInfo.indexOf(squirrel.getName());
							count=count/squirrel.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, squirrel.getName(),squirrel.getName()+"  *"+count+"\n");
						}
						break;
					case 7:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,rabbit.getName());
						if(Login.user.shopInfo.indexOf(rabbit.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(rabbit.getName())-Login.user.shopInfo.indexOf(rabbit.getName());
							count=count/rabbit.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, rabbit.getName(),rabbit.getName()+"  *"+count+"\n");
						}
						break;
					case 8:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,snake.getName());
						if(Login.user.shopInfo.indexOf(snake.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(snake.getName())-Login.user.shopInfo.indexOf(snake.getName());
							count=count/snake.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, snake.getName(),snake.getName()+"  *"+count+"\n");
						}
						break;
					case 9:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,lizard.getName());
						if(Login.user.shopInfo.indexOf(lizard.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(lizard.getName())-Login.user.shopInfo.indexOf(lizard.getName());
							count=count/lizard.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, lizard.getName(),lizard.getName()+"  *"+count+"\n");
						}
						break;
					case 10:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,fish.getName());
						if(Login.user.shopInfo.indexOf(fish.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(fish.getName())-Login.user.shopInfo.indexOf(fish.getName());
							count=count/fish.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, fish.getName(),fish.getName()+"  *"+count+"\n");
						}
						break;
					case 11:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,myna.getName());
						if(Login.user.shopInfo.indexOf(myna.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(myna.getName())-Login.user.shopInfo.indexOf(myna.getName());
							count=count/myna.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, myna.getName(),myna.getName()+"  *"+count+"\n");
						}
						break;
					case 12:
						carShopShowMessage=clear(carShopShowMessage, Login.user.shopInfo,canary.getName());
						if(Login.user.shopInfo.indexOf(canary.getName())!=-1)
						{
							count=Login.user.shopInfo.lastIndexOf(canary.getName())-Login.user.shopInfo.indexOf(canary.getName());
							count=count/canary.getName().length()+1;
							carShopShowMessage=sort(carShopShowMessage, canary.getName(),canary.getName()+"  *"+count+"\n");
						}
						break;
					default:
						break;
					}
					if(!carShopShowMessage.isEmpty())
					{
						int n=carShopShowMessage.split("\n").length;
						if(n>=2)
						{
							if(carShopShowMessage.split("\n")[n-1].equals(carShopShowMessage.split("\n")[n-2]))
							{
								carShopShowMessage=carShopShowMessage.substring(0,carShopShowMessage.length()-carShopShowMessage.split("\n")[n-1].length()-1);
								JOptionPane.showMessageDialog(PetComplexInfo.this,carShopShowMessage+"\n�ܼ�  "+Login.user.shopPrice);
								return;
							}
						}
	
					}
					if(!Login.user.shopInfo.isEmpty())
						JOptionPane.showMessageDialog(PetComplexInfo.this,carShopShowMessage+"\n�ܼ�  "+Login.user.shopPrice);
					else {
						JOptionPane.showMessageDialog(PetComplexInfo.this,"�ף�����û�й������\n��ȥ��������");
					}
				
				
			}
		});
		//�鿴��ť
		balace.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(PetComplexInfo.this,"�����˻����Ϊ: "+Login.user.getBalance());
			}
		});
		//��ֵ��ť
		chongz.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				float bala=0;
				try {
					bala=Float.parseFloat(JOptionPane.showInputDialog("�����ֵ���"));
				} catch (Exception e2) {
					bala=0f;// TODO: handle exception
				}
				Login.user.setBalance(bala);// TODO Auto-generated method stub
				
			}
		});
		//ȡ������ť
		jiangou.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				switch (id) {
				case 1:
					if(Login.user.shopInfo.endsWith(dog.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-dog.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(dog.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 2:
					if(Login.user.shopInfo.endsWith(cat.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-cat.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(cat.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 3:
					if(Login.user.shopInfo.endsWith(turtle.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-turtle.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(turtle.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 4:
					if(Login.user.shopInfo.endsWith(parrot.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-parrot.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(parrot.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 5:
					if(Login.user.shopInfo.endsWith(hamster.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-hamster.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(hamster.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 6:
					if(Login.user.shopInfo.endsWith(squirrel.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-squirrel.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(squirrel.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 7:
					if(Login.user.shopInfo.endsWith(rabbit.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-rabbit.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(rabbit.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 8:
					if(Login.user.shopInfo.endsWith(snake.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-snake.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(snake.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 9:
					if(Login.user.shopInfo.endsWith(lizard.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-lizard.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(lizard.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 10:
					if(Login.user.shopInfo.endsWith(fish.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-fish.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(fish.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 11:
					if(Login.user.shopInfo.endsWith(myna.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-myna.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(myna.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				case 12:
					if(Login.user.shopInfo.endsWith(canary.getName()+"\n")&&(Login.user.shopNumber-1)>=0)
					{
						Login.user.shopInfo=Login.user.shopInfo.substring(0, Login.user.shopInfo.length()-canary.getName().length()-1);
						Login.user.calPrice(Login.user.shopPrice, -Float.parseFloat(canary.price().split(" ")[1]));
						Login.user.shopNumber--;
						shopCar.setText("���ﳵ"+String.valueOf(Login.user.shopNumber));
					}
					break;
				default:
					break;
				}
			}
		});
		//����ť ����ɹ�֮���������
		buyButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if(new String("Y").equalsIgnoreCase(JOptionPane.showInputDialog("������Y or N ȷ���Ƿ���")))
					{
						if(Login.user.shopNumber==0)
						{
							switch (id) {
							case 1:
								buy=buy+dog.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(dog.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
									
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 2:
								buy=buy+cat.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(cat.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 3:
								buy=buy+turtle.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(turtle.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 4:
								buy=buy+parrot.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(parrot.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 5:
								buy=buy+hamster.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(hamster.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 6:
								buy=buy+squirrel.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(squirrel.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 7:
								buy=buy+rabbit.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(rabbit.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 8:
								buy=buy+snake.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(snake.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
								shopCar.setText("���ﳵ");
								
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 9:
								buy=buy+lizard.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(lizard.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 10:
								buy=buy+fish.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(fish.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 11:
								buy=buy+myna.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(myna.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							case 12:
								buy=buy+canary.getName()+" "+"*1"+"\n";
								if(!Login.user.buy(Float.parseFloat(canary.price().split(" ")[1]))||!ConnectMysql.canBuy(buy))
								{
									JOptionPane.showMessageDialog(PetComplexInfo.this, "���(���)����\n����ʧ��\n���ֵ");
									buy="";
								}
								else {
									Login.user.buyClear();
									shopCar.setText("���ﳵ");
									JOptionPane.showMessageDialog(PetComplexInfo.this, "��ϲ������ɹ�");
								}
								break;
							default:
								break;
							}
							if(!buy.isEmpty())
								ConnectMysql.setSellNumber(buy);
							buy="";
						}
						else {
							buy=buy+carShopShowMessage;
							if(!Login.user.buy(Login.user.shopPrice)||!ConnectMysql.canBuy(buy))
							{
								JOptionPane.showMessageDialog(PetComplexInfo.this,  "���(���)����\n����ʧ��\n���ֵ");
								buy="";
							}
				
							else {
								
								ConnectMysql.setSellNumber(buy);
								buy="";
								Login.user.buyClear();
								shopCar.setText("���ﳵ");
								String comment="";
								String enter="y";
								while(enter.equalsIgnoreCase("y"))
								{
									try {
										enter=JOptionPane.showInputDialog("��ϲ������ɹ�\n���Ҫ(����)�Թ�����Ʒ����\n�����y(�����ִ�Сд)");
										if(enter.equalsIgnoreCase("y"))
										{
											comment=comment+JOptionPane.showInputDialog("������Ҫ���۵ĳ�������\nȻ�����ֺ�\n���������Ա���������")+"\n";
											JOptionPane.showMessageDialog(null,"��ϲ�����۳ɹ�\nϵͳ����֮�������ῴ���Ա���������");
										}
									} catch (Exception e2) {
										comment="";
										enter="n";// TODO: handle exception
									}
								}
								if(!comment.isEmpty())
								{
									ConnectMysql.setComment(comment);
								}
								
							}
						}// TODO Auto-generated method stub
						
					}
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(PetComplexInfo.this,"лл����");// TODO: handle exception
				}
				
				
			}
		});
	}
	//������������������ ʹ���û�չʾ�Ĺ��ﳵ��Ϣ  �����Ի�
	public String sort(String carShopMess,String petName,String other)
	{
			if(carShopMess.contains(petName))
			{
				for(String item:carShopMess.split("\n"))
				{
					if(item.split("  ")[0].equals(petName))
					{
						carShopMess=carShopMess.replace(item+"\n",other );
						return carShopMess;
					}
				}
				
			}
		carShopMess=carShopMess+other;
		return carShopMess;
	}
	public String clear(String carShopMess,String carInfo,String petName)
	{
		if(!carInfo.contains(petName))
		{
			if(carShopMess.contains(petName))
			{
				for(String item:carShopMess.split("\n"))
				{
					if(item.split("  ")[0].equals(petName))
					{
						return carShopMess.replace(item+"\n", "");
					}
				}
			}
		}
		return carShopMess;
	}
}
