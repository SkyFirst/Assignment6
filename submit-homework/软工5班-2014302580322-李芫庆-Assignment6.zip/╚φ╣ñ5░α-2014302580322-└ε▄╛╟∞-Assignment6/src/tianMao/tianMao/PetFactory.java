package tianMao;
//���﹤����
public class PetFactory {
	public Dog1 getDog1()
	{
		return new Dog1();
	}
	public Cat2 getCat2()
	{
		return new Cat2();
	}
	public Turtle3 getTurtle3()
	{
		return new Turtle3();
	}
	public Parrot4 getParrot4()
	{
		return new Parrot4();
	}
	public Hamster5 getHamster5()
	{
		return new Hamster5();
	}
	public Squirrel6 getSquirrel6()
	{
		return new Squirrel6();
	}
	public Rabbit7 getRabbit7()
	{
		return new Rabbit7();
	}
	public Snake8 getSnake8()
	{
		return new Snake8();
	}
	public Lizard9 getLizard9()
	{
		return new Lizard9();
	}
	public Fish10 getFish10()
	{
		return new Fish10();
	}
	public Myna11 getMyna11()
	{
		return new Myna11();
	}
	public Canary12 getCanary12()
	{
		return new Canary12();
	}
}
