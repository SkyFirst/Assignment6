package tianMao;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
/*
 * APP��
 */
public class App extends JFrame {
	private Login login=new Login();
	//�����ڲ�ͬ�����л�
	protected static CardLayout cardLayout;
	protected static Container container;
	private PetSimpleInfo petSimpleInfo=new PetSimpleInfo();
	private PetComplexInfo petComplexInfo;
	public App()
	{
		setTitle("��è�̳�");
		cardLayout=new CardLayout();
		setLayout(cardLayout);
		setSize(400,200);
		setResizable(false);
		setLocation(Toolkit.getDefaultToolkit().getScreenSize().width/2-200,Toolkit.getDefaultToolkit().getScreenSize().height/2-100);
		container=getContentPane();
		container.add(login);
		container.add("0",petSimpleInfo);
		petComplexInfo=new PetComplexInfo(1);
		container.add("1",petComplexInfo);
		petComplexInfo=new PetComplexInfo(2);
		container.add("2",petComplexInfo);
		petComplexInfo=new PetComplexInfo(3);
		container.add("3",petComplexInfo);
		petComplexInfo=new PetComplexInfo(4);
		container.add("4",petComplexInfo);
		petComplexInfo=new PetComplexInfo(5);
		container.add("5",petComplexInfo);
		petComplexInfo=new PetComplexInfo(6);
		container.add("6",petComplexInfo);
		petComplexInfo=new PetComplexInfo(7);
		container.add("7",petComplexInfo);
		petComplexInfo=new PetComplexInfo(8);
		container.add("8",petComplexInfo);
		petComplexInfo=new PetComplexInfo(9);
		container.add("9",petComplexInfo);
		petComplexInfo=new PetComplexInfo(10);
		container.add("10",petComplexInfo);
		petComplexInfo=new PetComplexInfo(11);
		container.add("11",petComplexInfo);
		petComplexInfo=new PetComplexInfo(12);
		container.add("12",petComplexInfo);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		//����ѯ���Ƿ��˳�app
		addWindowListener(new WindowAdapter() {
			 public void windowClosing(WindowEvent e) {
				    if(JOptionPane.showConfirmDialog(null,"�Ƿ��˳�")==JOptionPane.OK_OPTION)
				    {		ConnectMysql.close();
				    		 System.exit(0);
				    }
				    
		  }
		});
		setVisible(true);
		
	}
}
