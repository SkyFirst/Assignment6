package tianMao;
/*
 * dog��
 */
public class Dog1 extends Things {

	public Dog1()
	{
		Id=1;
	}
	@Override
	public String eat() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[1];
	}

	@Override
	public String drink() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[2];
	}

	@Override
	public String live() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[3];
	}

	@Override
	public String hobby() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[4];
	}

	@Override
	public String price() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[5];
	}

	@Override
	public String comment() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[8];
	}

	@Override
	public int sellNumbers() {
		// TODO Auto-generated method stub
		return Integer.parseInt(ConnectMysql.getInfo(Id).split("\\+")[6]);
	}

	@Override
	public int leftNumbers() {
		// TODO Auto-generated method stub
		return Integer.parseInt(ConnectMysql.getInfo(Id).split("\\+")[7]);
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return ConnectMysql.getInfo(Id).split("\\+")[0];
	}
	@Override
	public int getID() {
		// TODO Auto-generated method stub
		return Id;
	}

}
